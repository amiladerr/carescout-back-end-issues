package com.carescout.carescoutbe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import java.lang.*;
@SpringBootApplication
public class CarescoutBeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarescoutBeApplication.class, args);
	}

}
