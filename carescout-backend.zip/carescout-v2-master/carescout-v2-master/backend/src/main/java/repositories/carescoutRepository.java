package repositories;

import Models.tableForDatabase;
import org.springframework.data.jpa.repository.JpaRepository;

public interface carescoutRepository extends JpaRepository <tableForDatabase, Long> {
}
