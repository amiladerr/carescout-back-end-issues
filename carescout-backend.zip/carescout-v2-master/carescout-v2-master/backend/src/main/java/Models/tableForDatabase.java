package Models;

import lombok.*;

import javax.persistence.*;

@Entity
@Table(name="firstTableForDatabase")
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class tableForDatabase {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column(name="name")
    private String name;
    @Column(name="lastName")
    private String lastName;
    @Column(name="is_role")
    private String role;
}
