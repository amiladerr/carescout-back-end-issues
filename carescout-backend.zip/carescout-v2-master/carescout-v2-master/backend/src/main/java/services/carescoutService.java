package services;

import Models.tableForDatabase;
import org.springframework.stereotype.Service;
import repositories.carescoutRepository;

import java.util.ArrayList;
import java.util.List;

@Service
public class carescoutService {
    private final List<tableForDatabase> resultList;

    private final carescoutRepository carescoutRepository;


    private tableForDatabase person(String amila, String dervisevic, int i, String student) {
        return null;
    }
    public carescoutService (carescoutRepository carescoutRepository){
        this.carescoutRepository = carescoutRepository;
        resultList = new ArrayList<>();
        resultList.add(person("amila", "dervisevic", 22, "student"));
    }


    public tableForDatabase create(tableForDatabase model){
        return carescoutRepository.save(model);


    }


    public List <tableForDatabase> getData(){
        return  carescoutRepository.findAll();

    }
}
