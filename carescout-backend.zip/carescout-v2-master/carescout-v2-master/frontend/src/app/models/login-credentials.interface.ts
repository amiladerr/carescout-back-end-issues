export interface LoginCredentials {
    username: string;
    password: string;
}