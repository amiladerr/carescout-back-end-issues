export interface ICareScouter{
    name:string;
    surname:string;
    phone:string;
    address:string;
}